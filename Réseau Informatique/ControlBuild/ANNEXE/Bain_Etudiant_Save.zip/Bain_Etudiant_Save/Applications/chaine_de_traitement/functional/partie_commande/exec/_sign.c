int getSignature(void) { return 
107141379; }
int getGenerationTime(void) { return 
1133785229; }
