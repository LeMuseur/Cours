#include "cb_products.h"
#ifndef GEN_EMBEDDED
#include "chaine_de_traitement/functional/robot/exec/robot.h"
#else
#include "chaine_de_traitement_robot.h"
#endif

int indexTabInstance;

int executionTab[1][1];

void initializeExecutionTab()
{
	executionTab[0][0] = 0;
}

int execNode(int numNode)
{
	return(1);
}

int behaviorsStep()
{
	CB_Object old_self = self;
	int old_self_num = self_num;
	CB_Mem_Bool *old_booleen = self.Bool;
	CB_Mem_Float *old_reel = self.Float;
	CB_Mem_Int *old_entier = self.Int;
	CB_Mem_Char *old_char = self.Char;

	indexTabInstance = 0;
	{
		robot_Accrocher = self.Bool++;
		robot_Monter = self.Bool++;
		robot_Descendre = self.Bool++;
		robot_Marche_Arriere = self.Bool++;
		robot_Marche_Avant = self.Bool++;
		robot_NivBas = self.Bool++;
		robot_NivHaut = self.Bool++;
		robot_P5 = self.Bool++;
		robot_P4 = self.Bool++;
		robot_P3 = self.Bool++;
		robot_P2 = self.Bool++;
		robot_P1 = self.Bool++;
		robot__num = self_num;
		{int __ret=chaine_de_traitement__robot(); if(__ret != 0)  return __ret;}
	}
	self_num = old_self_num;
	return 0;
}

/* Actors and products initialization */ 
T_ElementTableActeursProduits TableActeursProduits[] = {
	{{0, 0, 0, 0}, {0, 0, 0, 0},
	0, 0, 0, 0, {{0, 0}, {0, 0}}}
};
T_Instance NbActeurs = 0;
T_Instance NbProduits = 0;
T_Instance NbActeursEtProduits = 0;

void globalesInit()
{
}
/* Initialisation destailles m�moire */
void memorySizeInit(CB_Offset *minSize,CB_Offset *maxSize,CB_Offset *memSize)
{
	extern int withExchange;

	minSize->Bool = 0;
	minSize->Int = 0;
	minSize->Float = 0;
	minSize->Char = 0;
	withExchange = 0;
	maxSize->Bool = 17;
	maxSize->Int = 429;
	maxSize->Float = 17;
	maxSize->Char = 53;
	memSize->Bool = 17;
	memSize->Int = 429;
	memSize->Float = 17;
	memSize->Char = 53;
}


/* Location of memory starts*/
void memoryStartInit(CB_Object *pMem)
{
	extern int minBool,minInt,minFloat,minChar;

	pMem->Bool += minBool+5;
	pMem->Int += minInt+209;
	pMem->Float += minFloat+7;
	pMem->Char  += minChar +53;
}

/* Not Null Variables initialization */
void CB_Bool_Init(char *Mem, int index, CB_Bool value)
{
	P_Bool(Mem,index)->CB_current_value = value;
	P_Bool(Mem,index)->CB_previous_value = value;
}

void CB_Int_Init(char *Mem, int index, CB_Int value)
{
	P_Int(Mem,index)->CB_current_value = value;
	P_Int(Mem,index)->CB_previous_value = value;
}

void CB_Float_Init(char *Mem, int index, CB_Float value)
{
	P_Float(Mem,index)->CB_current_value = value;
	P_Float(Mem,index)->CB_previous_value = value;
}

void CB_Char_Init(char *Mem, int index, CB_Char value)
{
	P_Char(Mem,index)->CB_current_value = value;
	P_Char(Mem,index)->CB_previous_value = value;
}

void variablesInitialization()
{
	char *Mem = (char *) memHeader;

	/* Booleans */
	CB_Bool_Init(Mem,3,1);
	CB_Bool_Init(Mem,4,1);
	/* Integers */
	CB_Int_Init(Mem,421,200);
	CB_Int_Init(Mem,422,800);
	CB_Int_Init(Mem,423,3);
	CB_Int_Init(Mem,424,5);
	/* Reals */
	CB_Float_Init(Mem,10,50000.0);
	/* Characters */
	/* Arrays */
	CB_Int_Init(Mem,211,100);
	CB_Int_Init(Mem,313,100);
	CB_Char_Init(Mem,1,50);
	CB_Char_Init(Mem,3,114);
	CB_Char_Init(Mem,4,111);
	CB_Char_Init(Mem,5,98);
	CB_Char_Init(Mem,6,111);
	CB_Char_Init(Mem,7,116);
	CB_Char_Init(Mem,8,46);
	CB_Char_Init(Mem,9,101);
	CB_Char_Init(Mem,10,120);
	CB_Char_Init(Mem,11,101);
}

/* Acces aux variables de contr�le */

void controlVariablesAccessInitialization()
{
	char *Mem = (char *) memHeader;
	extern CB_Mem_Bool *traceon;
	extern CB_Mem_Bool *resettrace;
	extern CB_Mem_Bool *cb_delay;
	extern CB_Mem_Bool *allowpreconditions;
	extern CB_Mem_Bool *allowpostconditions;
	/* Integers */
	extern CB_Mem_Int *execstatus;
	extern CB_Mem_Int *bpnoline;
	extern CB_Mem_Int *bpnoinstance;
	extern CB_Mem_Int *bpcurrentinstance;
	extern CB_Mem_Int *bpcurrentlocation;
	extern CB_Mem_Int *signature;
	extern CB_Mem_Int *generationtime;
	/* Reals */
	extern CB_Mem_Float *simuperiod;
	extern CB_Mem_Float *maxsimuperiod;
	extern CB_Mem_Float *minsimuperiod;
	extern CB_Mem_Float *realsimuperiod;
	extern CB_Mem_Float *mxmeanvariablemodification;
	extern CB_Mem_Float *mxminvariablemodification;
	extern CB_Mem_Float *mxmaxvariablemodification;
	/* Characters */
	extern CB_Mem_Char *taskname;

	/* Booleans */
	traceon=P_Bool(Mem,0);
	resettrace=P_Bool(Mem,1);
	cb_delay=P_Bool(Mem,2);
	allowpreconditions=P_Bool(Mem,3);
	allowpostconditions=P_Bool(Mem,4);
	/* Integers */
	execstatus=P_Int(Mem,210);
	bpnoline=P_Int(Mem,211);
	bpnoinstance=P_Int(Mem,313);
	bpcurrentinstance=P_Int(Mem,415);
	bpcurrentlocation=P_Int(Mem,416);
	signature=P_Int(Mem,417);
	generationtime=P_Int(Mem,418);
	/* Reals */
	simuperiod=P_Float(Mem,10);
	maxsimuperiod=P_Float(Mem,12);
	minsimuperiod=P_Float(Mem,11);
	realsimuperiod=P_Float(Mem,13);
	mxmeanvariablemodification=P_Float(Mem,14);
	mxminvariablemodification=P_Float(Mem,15);
	mxmaxvariablemodification=P_Float(Mem,16);
	/* Characters */
	taskname=P_Char(Mem,0);
}

/* Time cycle initialization */
void timeCycleInitialization(CB_Mem_Float *timecycle)
{
	timecycle->CB_current_value =  50000;
}

/* Starting mode */
void initStartingMode(CB_Mem_Int *execstatus)
{
	execstatus->CB_current_value =  mx_exec_status_stop;
}

/* Execution mode */
void initExecutionMode(CB_Mem_Bool *delay)
{
	delay->CB_current_value =  0;
}
