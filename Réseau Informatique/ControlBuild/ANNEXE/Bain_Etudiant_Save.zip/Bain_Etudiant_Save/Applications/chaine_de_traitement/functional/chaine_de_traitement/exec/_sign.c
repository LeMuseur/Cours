unsigned int getSignature(void) { return 
876834836u; }
int getGenerationTime(void) { return 
1169739101; }
