int getSignature(void) { return 
113170914; }
int getGenerationTime(void) { return 
1129927892; }
