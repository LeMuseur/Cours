#include "cb_products.h"
#ifndef GEN_EMBEDDED
#include "chaine_de_traitement/functional/gestion_priorites/exec/gestion_priorites.h"
#else
#include "chaine_de_traitement_gestion_priorites.h"
#endif
#ifndef GEN_EMBEDDED
#include "fg/functional/fifo_obj/exec/fifo_obj.h"
#else
#include "fg_fifo_obj.h"
#endif

#include <stdio.h>

int indexTabInstance;

int executionTab[1][1];

void initializeExecutionTab()
{
	executionTab[0][0] = 0;
}

int execNode(int numNode)
{
	return(1);
}


int behaviorsStep()
{
	CB_Object old_self = self;
	int old_self_num = self_num;
	CB_Mem_Bool *old_booleen = self.Bool;
	CB_Mem_Float *old_reel = self.Float;
	CB_Mem_Int *old_entier = self.Int;
	CB_Mem_Char *old_char = self.Char;

	indexTabInstance = 0;
	{
		gestion_priorites_Ecrire_Valeur = self.Bool++;
		gestion_priorites_Lire_Valeur = self.Bool++;
		gestion_priorites_Valeur_A_Ecrire = self.Int++;
		gestion_priorites_Valeur_Lue = self.Int++;
		gestion_priorites_Vide = self.Bool++;
		gestion_priorites_Occupee = self.Bool++;
		gestion_priorites__num = self_num;
		{int __ret=chaine_de_traitement__gestion_priorites(); if(__ret != 0)  return __ret;}
	}
	self_num = old_self_num;
	return 0;
}

/* Actors and products initialization */ 
T_ElementTableActeursProduits TableActeursProduits[] = {
	{{0, 0, 0, 0}, {0, 0, 0, 0},
	0, 0, 0, 0, {{0, 0}, {0, 0}}}
};
T_Instance NbActeurs = 0;
T_Instance NbProduits = 0;
T_Instance NbActeursEtProduits = 0;

void globalesInit()
{
}
/* Initialisation destailles m�moire */
void memorySizeInit(CB_Offset *minSize,CB_Offset *maxSize,CB_Offset *memSize)
{
	extern int withExchange;

	minSize->Bool = 0;
	minSize->Int = 0;
	minSize->Float = 0;
	minSize->Char = 0;
	withExchange = 0;
	maxSize->Bool = 17;
	maxSize->Int = 438;
	maxSize->Float = 17;
	maxSize->Char = 53;
	memSize->Bool = 17;
	memSize->Int = 438;
	memSize->Float = 17;
	memSize->Char = 53;
}


/* Location of memory starts*/
void memoryStartInit(CB_Object *pMem)
{
	extern int minBool,minInt,minFloat,minChar;

	pMem->Bool += minBool+5;
	pMem->Int += minInt+209;
	pMem->Float += minFloat+7;
	pMem->Char  += minChar +53;
}

/* Not Null Variables initialization */
void CB_Bool_Init(char *Mem, int index, CB_Bool value)
{
	P_Bool(Mem,index)->CB_current_value = value;
	P_Bool(Mem,index)->CB_previous_value = value;
}

void CB_Int_Init(char *Mem, int index, CB_Int value)
{
	P_Int(Mem,index)->CB_current_value = value;
	P_Int(Mem,index)->CB_previous_value = value;
}

void CB_Float_Init(char *Mem, int index, CB_Float value)
{
	P_Float(Mem,index)->CB_current_value = value;
	P_Float(Mem,index)->CB_previous_value = value;
}

void CB_Char_Init(char *Mem, int index, CB_Char value)
{
	P_Char(Mem,index)->CB_current_value = value;
	P_Char(Mem,index)->CB_previous_value = value;
}

void variablesInitialization()
{
	char *Mem = (char *) memHeader;

	/* Booleans */
	CB_Bool_Init(Mem,3,1);
	CB_Bool_Init(Mem,4,1);
	CB_Bool_Init(Mem,7,1);
	/* Integers */
	CB_Int_Init(Mem,420,-1);
	CB_Int_Init(Mem,428,1);
	CB_Int_Init(Mem,429,1);
	/* Reals */
	CB_Float_Init(Mem,10,50000.0);
	/* Characters */
	/* Arrays */
	CB_Int_Init(Mem,421,5);
	CB_Int_Init(Mem,211,100);
	CB_Int_Init(Mem,313,100);
	CB_Char_Init(Mem,1,50);
	CB_Char_Init(Mem,3,103);
	CB_Char_Init(Mem,4,101);
	CB_Char_Init(Mem,5,115);
	CB_Char_Init(Mem,6,116);
	CB_Char_Init(Mem,7,105);
	CB_Char_Init(Mem,8,111);
	CB_Char_Init(Mem,9,110);
	CB_Char_Init(Mem,10,95);
	CB_Char_Init(Mem,11,112);
	CB_Char_Init(Mem,12,114);
	CB_Char_Init(Mem,13,105);
	CB_Char_Init(Mem,14,111);
	CB_Char_Init(Mem,15,114);
	CB_Char_Init(Mem,16,105);
	CB_Char_Init(Mem,17,116);
	CB_Char_Init(Mem,18,101);
	CB_Char_Init(Mem,19,115);
	CB_Char_Init(Mem,20,46);
	CB_Char_Init(Mem,21,101);
	CB_Char_Init(Mem,22,120);
	CB_Char_Init(Mem,23,101);
}

/* Acces aux variables de contr�le */

void controlVariablesAccessInitialization()
{
	char *Mem = (char *) memHeader;
	extern CB_Mem_Bool *traceon;
	extern CB_Mem_Bool *resettrace;
	extern CB_Mem_Bool *cb_delay;
	extern CB_Mem_Bool *allowpreconditions;
	extern CB_Mem_Bool *allowpostconditions;
	/* Integers */
	extern CB_Mem_Int *execstatus;
	extern CB_Mem_Int *bpnoline;
	extern CB_Mem_Int *bpnoinstance;
	extern CB_Mem_Int *bpcurrentinstance;
	extern CB_Mem_Int *bpcurrentlocation;
	extern CB_Mem_Int *signature;
	extern CB_Mem_Int *generationtime;
	/* Reals */
	extern CB_Mem_Float *simuperiod;
	extern CB_Mem_Float *maxsimuperiod;
	extern CB_Mem_Float *minsimuperiod;
	extern CB_Mem_Float *realsimuperiod;
	extern CB_Mem_Float *mxmeanvariablemodification;
	extern CB_Mem_Float *mxminvariablemodification;
	extern CB_Mem_Float *mxmaxvariablemodification;
	/* Characters */
	extern CB_Mem_Char *taskname;

	/* Booleans */
	traceon=P_Bool(Mem,0);
	resettrace=P_Bool(Mem,1);
	cb_delay=P_Bool(Mem,2);
	allowpreconditions=P_Bool(Mem,3);
	allowpostconditions=P_Bool(Mem,4);
	/* Integers */
	execstatus=P_Int(Mem,210);
	bpnoline=P_Int(Mem,211);
	bpnoinstance=P_Int(Mem,313);
	bpcurrentinstance=P_Int(Mem,415);
	bpcurrentlocation=P_Int(Mem,416);
	signature=P_Int(Mem,417);
	generationtime=P_Int(Mem,418);
	/* Reals */
	simuperiod=P_Float(Mem,10);
	maxsimuperiod=P_Float(Mem,12);
	minsimuperiod=P_Float(Mem,11);
	realsimuperiod=P_Float(Mem,13);
	mxmeanvariablemodification=P_Float(Mem,14);
	mxminvariablemodification=P_Float(Mem,15);
	mxmaxvariablemodification=P_Float(Mem,16);
	/* Characters */
	taskname=P_Char(Mem,0);
}

/* Time cycle initialization */
void timeCycleInitialization(CB_Mem_Float *timecycle)
{
	timecycle->CB_current_value =  50000;
}

/* Starting mode */
void initStartingMode(CB_Mem_Int *execstatus)
{
	execstatus->CB_current_value =  mx_exec_status_stop;
}

/* Execution mode */
void initExecutionMode(CB_Mem_Bool *delay)
{
	delay->CB_current_value =  0;
}
