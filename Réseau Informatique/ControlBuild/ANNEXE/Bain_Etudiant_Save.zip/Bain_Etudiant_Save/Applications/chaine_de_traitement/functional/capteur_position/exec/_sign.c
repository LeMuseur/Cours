int getSignature(void) { return 
107726588; }
int getGenerationTime(void) { return 
1129653564; }
