int getSignature(void) { return 
108118624; }
int getGenerationTime(void) { return 
1129928111; }
