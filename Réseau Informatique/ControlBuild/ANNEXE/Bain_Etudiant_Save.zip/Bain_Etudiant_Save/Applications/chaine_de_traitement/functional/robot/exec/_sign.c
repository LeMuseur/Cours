int getSignature(void) { return 
124953414; }
int getGenerationTime(void) { return 
1129307642; }
