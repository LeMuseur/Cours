int getSignature(void) { return 
109790286; }
int getGenerationTime(void) { return 
1129282684; }
