unsigned int getSignature(void) { return 
543097897u; }
int getGenerationTime(void) { return 
1169735603; }
