int getSignature(void) { return 
123997017; }
int getGenerationTime(void) { return 
1139649130; }
