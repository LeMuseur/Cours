int getSignature(void) { return 
108030067; }
int getGenerationTime(void) { return 
1133784913; }
