void fifo (CB_Mem_Int *, CB_Mem_Bool *, CB_Mem_Bool *, CB_Mem_Bool *, CB_Mem_Int *, CB_Mem_Bool *, CB_Mem_Int *, CB_Mem_Bool *);

