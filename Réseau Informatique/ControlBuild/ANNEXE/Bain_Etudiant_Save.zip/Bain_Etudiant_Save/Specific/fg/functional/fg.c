#include "cb_memory.h"
#include "fg.h"
#include "iec_1131.h"
#include <setjmp.h>
extern int LIBFB_ERR;


extern CB_Object self;
extern CB_Object mem;


void fifo(CB_Mem_Int *fifo_Valeur_A_Ecrire, CB_Mem_Bool *fifo_Lire_Valeur, CB_Mem_Bool *fifo_Ecrire_Valeur, CB_Mem_Bool *fifo_tmp1, CB_Mem_Int *fifo_step_counter, CB_Mem_Bool *fifo_Vide, CB_Mem_Int *fifo_Valeur_Lue, CB_Mem_Bool *fifo_Occupee)
{
#define COUR(v) (fifo_##v->CB_current_value)
#define FIGE(v) (fifo_##v->CB_previous_value)
#define FM(v) (fifo_##v->CB_positive_edge)
#define FD(v) (fifo_##v->CB_negative_edge)


#define Valeur_A_Ecrire fifo_Valeur_A_Ecrire->CB_current_value
#define Lire_Valeur fifo_Lire_Valeur->CB_current_value
#define Ecrire_Valeur fifo_Ecrire_Valeur->CB_current_value
#define tmp1 fifo_tmp1->CB_current_value
#define fifo_tmp1 fifo_tmp1
#define step_counter fifo_step_counter->CB_current_value
#define Vide fifo_Vide->CB_current_value
#define Valeur_Lue fifo_Valeur_Lue->CB_current_value
#define Occupee fifo_Occupee->CB_current_value

	Vide = 0;
	if((Lire_Valeur & !tmp1)) {
		if((Valeur_Lue == -1)) {
			Valeur_Lue = 0;
		}
		Valeur_Lue = (Valeur_Lue + 1);
		if((Valeur_Lue == 6)) {
			Valeur_Lue = 1;
		}
	}
	tmp1 = Lire_Valeur;

#undef Valeur_A_Ecrire
#undef Lire_Valeur
#undef Ecrire_Valeur
#undef tmp1
#undef fifo_tmp1
#undef step_counter
#undef Vide
#undef Valeur_Lue
#undef Occupee

#undef COUR
#undef FIGE
#undef FM
#undef FD
}


