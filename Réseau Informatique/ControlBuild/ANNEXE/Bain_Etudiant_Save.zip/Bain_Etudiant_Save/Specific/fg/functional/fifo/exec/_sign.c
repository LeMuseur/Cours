unsigned int getSignature(void) { return 
1305971424u; }
int getGenerationTime(void) { return 
1169737571; }
